﻿from openai import OpenAI
from pathlib import Path

text = Path('/mnt/d/usr/百信公司项目/pdfsc/output/d2_case_02_extracted_text.txt').read_text(encoding='utf-8')
base_url = 'http://127.0.0.1:11434/v1'
client = OpenAI(base_url=base_url, api_key='ollama')

def current_prompt(text):
    return (
        "你是技术文档还原助手。请严格忠实还原原文，不添加原文没有的信息。\n"
        "文档标题: TaiShan 200 服务器 快速安装指南 (型号2280)\n"
        "源文件: TaiShan 200 服务器 快速安装指南 (型号2280) 10.pdf\n"
        "以下是提取文本:\n" + text
    )


def strict_prompt(text):
    return (
        "你是PDF技术文档忠实还原助手。你的唯一任务是把输入内容整理为Markdown，不得总结、不得改写、不得补充、不得推测、不得省略、不得生成原文未出现的结论。"
        "若版面混乱，宁可保留原词句碎片，也不要自行解释。必须保留能识别出的标题、步骤、参数、警示、表格项。输出只写Markdown正文。\n"
        "文档标题: TaiShan 200 服务器 快速安装指南 (型号2280)\n"
        "源文件: TaiShan 200 服务器 快速安装指南 (型号2280) 10.pdf\n"
        "以下是提取文本:\n" + text
    )

experiments = [
    ('qwen2.5:1.5b', 'current', current_prompt(text)),
    ('qwen2.5:1.5b', 'strict', strict_prompt(text)),
    ('qwen2.5vl:3b', 'current', current_prompt(text)),
    ('qwen2.5vl:3b', 'strict', strict_prompt(text)),
]

out_dir = Path('/mnt/d/usr/百信公司项目/pdfsc/output/d2_prompt_compare')
out_dir.mkdir(parents=True, exist_ok=True)

for model, label, prompt in experiments:
    print('RUN', model, label, flush=True)
    resp = client.chat.completions.create(
        model=model,
        messages=[{'role': 'user', 'content': prompt}],
        temperature=0,
    )
    content = resp.choices[0].message.content or ''
    path = out_dir / f"{model.replace(':', '_')}_{label}.md"
    path.write_text(content, encoding='utf-8')
    print(path, flush=True)
