﻿# Ubuntu 安装与测试说明

## 1. 解压
```bash
tar -xzf pdfsc-ubuntu-installer-20260405.tar.gz
cd pdfsc-ubuntu-installer-20260405
```

## 2. 安装依赖
```bash
bash scripts/install.sh
```

## 3. 初始化配置
```bash
cp config/config.example.yml config/config.yml
# 按需编辑 config/config.yml
```

## 4. 运行最小测试（D2流程）
```bash
bash scripts/run_d2.sh flow-test
```

## 5. 单文件转换
```bash
python3 src/pdfsc.py convert ./pdfs/sample.pdf --config ./config/config.yml
```

## 6. 批量与验收
```bash
python3 src/pdfsc.py convert-batch ./pdfs --config ./config/config.yml
python3 src/pdfsc.py verify ./output
python3 src/pdfsc.py stats ./output
```

## 7. 常见问题
- 若用 ollama，需先确保服务可访问（默认 `http://localhost:11434/v1`）。
- 若仅验证流程，建议先用 mock 配置（`config/d2_flow.yml`）。
